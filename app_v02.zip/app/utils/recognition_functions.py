from subprocess import Popen, PIPE
import base64
import json
import os
import pandas as pd
import numpy as np
from PIL import Image
import boto3
import subprocess
import re
import numpy as np
import glob
import pymorphy2 
import requests

pd.set_option('display.max_columns', 500)

def pos(word, morth=pymorphy2.MorphAnalyzer()):
    "Return a likely part of speech for the *word*."""
    return morth.parse(word)[0].tag.POS


def translate_me(word, IAM_TOKEN, folderId):   
 
    r"""Yandex translate function"""
    
    out = {
        "folderId": folderId,
        "texts": [word],
        "targetLanguageCode": "ru"
    }        
    with open('body.json', 'w') as f:
        json.dump(out, f)
    os.system("export IAM_TOKEN="+IAM_TOKEN)
    os.system("curl -X POST -H \"Content-Type: application/json\" -H \"Authorization: Bearer "+IAM_TOKEN+"\" -d @body.json https://translate.api.cloud.yandex.net/translate/v2/translate >      output.json")
    with open("output.json", "r", encoding='utf-8') as read_file:
        trn_word = json.load(read_file)
   
    return trn_word['translations'][0]['text']


def text_recognition(photo, IAM_TOKEN, folderId):
    def encode_file(file):
        with open(file, 'rb') as f:
            file_content = f.read()
        return base64.b64encode(file_content).decode('utf-8')

    outfile = encode_file(photo)

    out = {
        "folderId": folderId,
        "analyze_specs": [{
            "content": outfile,
            "features": [{
                "type": "TEXT_DETECTION",
                "text_detection_config": {
                    "language_codes": ["*"]
                }
            }]
        }]
    }
        
    with open('body.json', 'w') as f:
        json.dump(out, f)
    os.system("export IAM_TOKEN="+IAM_TOKEN)
    os.system("curl -X POST -H \"Content-Type: application/json\" -H \"Authorization: Bearer "+IAM_TOKEN+"\" -d @body.json https://vision.api.cloud.yandex.net/vision/v1/batchAnalyze > output.json")

    with open("output.json", "r", encoding='utf-8') as read_file:
        img_word = json.load(read_file)
        img_word=img_word['results'][0]['results'][0]['textDetection']['pages'][0]['blocks']

    words=[]
    for obj in img_word:
        obj=obj['lines']
        for lines in obj:
            lines=lines['words']
            for word in lines: 
                words.append(word['text'])

    SYMBOLS = '{}()[].,:;+-*/&|<>=~$1234567890"@«'
    words=[item.translate(str.maketrans('','', SYMBOLS)).strip() for item in words]
    words=[item for item in words if len(item)>1]
    words=[item.lower() for item in words]
    words=[word.replace('?',"") for word in words]
    words=[word.replace('\r',"") for word in words]
    words=[word.replace('\n',"") for word in words]
    functors_pos = {'INTJ', 'PRCL', 'CONJ', 'PREP'}  # function words
    words=[word for word in words if pos(word) not in functors_pos]
    words = ['w_'+element for element in words]

    data=pd.DataFrame(words, columns=['Words'])
    data['Image_name']=photo
    wrd_cnt=data['Words'].value_counts().to_dict()
    data['Words_count']=data['Words'].map(wrd_cnt)
    data.drop_duplicates(subset ="Words", inplace = True)
    data.reset_index(drop=True)
    return(data)


def object_detection(photo, conf_level, dict_all, access_key_id, secret_access_key, ):
    
    r"""Amazon image recognition"""
    
    bucket='kanavis'
    conf_level = 0.1

    with open(photo, 'rb') as source_image:
        source_bytes=source_image.read()


    client=boto3.client('rekognition', aws_access_key_id = access_key_id, aws_secret_access_key = secret_access_key, region_name='us-east-2')  
    response=client.detect_labels(Image={'Bytes': source_bytes}, MaxLabels=10)
    img_obj=json.loads(json.dumps(response['Labels'])) 

    obj_names=[]
    obj_conf=[]
    for obj in img_obj:
        if obj['Confidence']>conf_level:
            obj_names.append(obj['Name'])
            obj_conf.append(obj['Confidence'])
    data_obj=pd.DataFrame(np.column_stack([obj_names, obj_conf]), columns=['Name', 'Confidence'])
    
    for x in set(data_obj['Confidence']): 
        names=list(data_obj[data_obj['Confidence']==x]['Name'])
        names_dict={x: names[0] for x in names} 
        dict_all={**dict_all, **names_dict}
    data_obj = data_obj[data_obj['Name'].isin(list(dict_all.values()))]

    data=pd.DataFrame(list(data_obj['Name']), columns=['Objects'])
    data['Image_name']=photo
    data['Image_count']=1

    return(data, dict_all)



def postproc_obj_detection(table, map_dict, IAM_TOKEN, folderId):
    
    r"""Function for postprocessing and transforming data to pivot format"""
    
    table['Objects']=table['Objects'].map(map_dict)
    obj_names=table['Objects'].to_list()
#     obj_names=[translate_me(x, IAM_TOKEN, folderId) for x in obj_names]
    obj_names=[x.lower() for x in obj_names]
    obj_names=['obj_'+element for element in obj_names]
    table['Objects']=obj_names
    table_obj = pd.pivot_table(table, values='Image_count', index=['Image_name'], columns=['Objects'], aggfunc=np.sum).reset_index()
    return table_obj
