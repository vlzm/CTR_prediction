import sys
import os
import pandas as pd
import glob
import pickle


def postprocess_recogn_table(table, cwd, size, threshold):
    data = table.copy()
    
    if 'Unnamed: 0' in list(data.columns):
        data = data.drop(columns = ['Unnamed: 0'])

    data['banner_size'] = data['Image_name'].apply(lambda x: x.split('_')[0])
    data['banner_id'] = data['Image_name'].apply(lambda x: x.split('_')[1])

    data = data.drop(columns = ['Image_name'])
    
    with open(cwd + '\\utils\\cleaned', 'rb') as f:
        clean_words = pickle.load(f)
    
    all_words = [x for x in list(data.columns) if 'w_' in x]
    delete_words = [x for x in list(data.columns) if 'w_' in x and x not in clean_words]
    data = data.drop(columns = delete_words)

    count_recogn_table = data.drop(columns = ['banner_id','banner_size']).sum().reset_index().groupby('index').sum().sort_values(by = 0).reset_index()
    count_recogn_table = count_recogn_table.rename(columns = {0:'count'})

    threshold = 25
    using_recogns = list(count_recogn_table[count_recogn_table['count'] > threshold].reset_index(drop = True)['index'].values)

    data = data[['banner_id','banner_size'] + using_recogns]

    recognized_table_size = data[data['banner_size'] == str(size)].reset_index(drop = True)
    recognized_table_size['banner_id'] = recognized_table_size['banner_id'].apply(lambda x: x.replace('.jpg',''))
    recognized_table_size['banner_id'] = recognized_table_size['banner_id'].apply(lambda x: x.replace('.png',''))
    recognized_table_size['banner_id'] = recognized_table_size['banner_id'].astype('int')
    
    return recognized_table_size

def merging_all(recogn_data, multi_table, raw_data, raw_data_merge, size):
    data_linking = raw_data[['banner_id', '256x256', '600x600', '1080x607']]
    target_name = str(size)
    
    if str(size) == '600':
        size = '600x600'
    elif str(size) == '1080':
        size = '1080x607'
    elif str(size) == '1080_256':
        size_1 = '1080x607'
        size_2 = '256x256'
    else:
        print('wrong size')
        
    
    recogn_data['banner_id'] = recogn_data['banner_id'].astype('int')
    recogn_data = pd.merge(recogn_data, data_linking[['banner_id', size]], on = ['banner_id'], how = 'left')
    recogn_data = pd.merge(data_linking[['banner_id', size]], recogn_data, on = [size], how = 'left')
    recogn_data = recogn_data.drop(columns = ['banner_id_y']).rename(columns = {'banner_id_x':'banner_id'})

    total_table = pd.merge(raw_data_merge, multi_table, on = ['banner_id'], how = 'left').dropna()
    total_table = pd.merge(total_table, recogn_data, on = ['banner_id'], how = 'left').dropna()
    total_table['CTR_' + target_name] = total_table['clicks']/total_table['shows']
    
    return total_table


def count_encoding(data, to_count_columns):
    for f in to_count_columns:
        vc = data[f].value_counts(dropna=False)
        data[f'_count_{f}'] = data[f].map(vc)

    count_columns = [x for x in data.columns if 'count_' in x]
    return count_columns

def one_hot_encoding(data, to_one_hot_columns):
    one_hot_columns = []
    for col in to_one_hot_columns:
        one_hot = pd.get_dummies(data[col])
        for hcol in one_hot.columns:
            one_hot = one_hot.rename(columns = {hcol:'one_hot_' + hcol})
            data['one_hot_' + hcol] = one_hot['one_hot_' + hcol]
        one_hot_columns.append(list(one_hot.columns))

    one_hot_columns = [item for sublist in one_hot_columns for item in sublist]
    return one_hot_columns

def target_encoding(data, to_target_mean_columns, target_name):    
    target_mean_columns = []
    for col in to_target_mean_columns:
        means = data[col].map(data.groupby(col)[target_name].mean())
        col_mean = 'target_mean_' + col
        data[col_mean] = means
        target_mean_columns.append(col_mean)
        
    data['CTR_mean'] = data[target_name].mean()
    target_mean_columns.append('CTR_mean')
    return target_mean_columns


def type_encoding(data, cat_features):
    for col in cat_features:
        data[col] = data[col].astype(int)
    return(data)


