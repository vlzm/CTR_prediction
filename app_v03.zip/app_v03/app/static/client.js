var el = x => document.getElementById(x);

function showPicker() {
  el("file-input").click();
}

function showPicker_2() {
  el("file-input_2").click();
}

function showPicker_3() {
  el("myText").click();
}

function showPicked(input) {
  el("upload-label").innerHTML = input.files[0].name;
  var reader = new FileReader();
  reader.onload = function(e) {
    el("image-picked").src = e.target.result;
    el("image-picked").className = "";
  };
  reader.readAsDataURL(input.files[0]);
}

function showPicked_2(input) {
  el("upload-label_2").innerHTML = input.files[0].name;
  var reader = new FileReader();
  reader.onload = function(e) {
    el("image-picked_2").src = e.target.result;
    el("image-picked_2").className = "";
  };
  reader.readAsDataURL(input.files[0]);
}

function showPicked_3(input) {
  el("token").innerHTML = input.files[0].name;
  var reader = new FileReader();
  reader.onload = function(e) {
    el("token").src = e.target.result;
    el("token").className = "";
  };
  reader.readAsDataURL(input.files[0]);
}

function analyze() {
  var uploadFiles = el("file-input").files;
  if (uploadFiles.length !== 1) alert("Please select a file to analyze!");

  el("analyze-button").innerHTML = "Analyzing...";
  var xhr = new XMLHttpRequest();
  var loc = window.location;
  xhr.open("POST", `${loc.protocol}//${loc.hostname}:${loc.port}/img-echo`,
    true);
  xhr.onerror = function() {
    alert(xhr.responseText);
  };
  xhr.onload = function(e) {
    if (this.readyState === 4) {
      var response = JSON.parse(e.target.responseText);
      el("result-label").innerHTML = `${response["result"]}`;
    }
    el("analyze-button").innerHTML = "Load";
  };

  var fileData = new FormData();
  fileData.append("file", uploadFiles[0]);
  xhr.send(fileData);
}


function analyze_2() {
  var uploadFiles = el("file-input_2").files;
  if (uploadFiles.length !== 1) alert("Please select a file to analyze!");

  el("analyze-button_2").innerHTML = "Analyzing...";
  var xhr = new XMLHttpRequest();
  var loc = window.location;
  xhr.open("POST", `${loc.protocol}//${loc.hostname}:${loc.port}/tables-echo`,
    true);

  xhr.onerror = function() {
    alert(xhr.responseText);
  };
  xhr.onload = function(e) {
    if (this.readyState === 4) {
      var response = JSON.parse(e.target.responseText);
      el("result-label_2").innerHTML = `${response["result"]}`;
    }
    el("analyze-button_2").innerHTML = "Load";
  };

  var fileData = new FormData();
  fileData.append("file", uploadFiles[0]);
  xhr.send(fileData);
}



function analyze_3() {
  var uploadFiles = document.getElementById("token").value;

  var xhr = new XMLHttpRequest();
  var loc = window.location;
  xhr.open("POST", `${loc.protocol}//${loc.hostname}:${loc.port}/predict`,
    true);

  xhr.onerror = function() {
    alert(xhr.responseText);
  };
  xhr.onload = function(e) {
    if (this.readyState === 4) {
      var response = JSON.parse(e.target.responseText);
      el("CTR").innerHTML = `Your CTR is: ` + `${response["Your CTR:"]}`;
    }
  };

  var fileData = new FormData();
  fileData.append("token", uploadFiles);
  xhr.send(fileData);
}













function analyze_31() {
  var x = el("token").value;
  var xhr = new XMLHttpRequest();
  xhttp.onreadystatechange=function(){
      if (xhttp.readyState==4 && xhttp.status==200)
         document.getElementById('ajax').innerHTML=xhttp.responseText;
   }
  xhr.open("POST", `${loc.protocol}//${loc.hostname}:${loc.port}/predict`,
    true);
  request.setRequestHeader("Content-Type","text/plain");
  xhr.send(x);
}



