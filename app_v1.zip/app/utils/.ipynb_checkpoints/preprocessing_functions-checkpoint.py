import sys
import os
import pandas as pd
import glob
import pickle


def preprocess_raw_table(data):
    raw_feachers = ['banner_id', 'topic_alias', 'SUM(shows)', 'SUM(clicks)', 'CTR', 'title',
           'cta_sites_full', 'primary', 'text_90', 'title_25', 'url']

    raw_data_merge = data[raw_feachers].copy()
    raw_data_merge['url'] = raw_data_merge['url'].astype('object').apply(lambda x: 'Empty' if isinstance(x, int) else x.split('/')[2])
    
    return raw_data_merge


def preprocess_multiformat_table(table, size):
    
    if str(size) == '600':
        names_size = ['мультиформат, квадратная картинка, без текста', 'Мультиформат, квадратная картинка']
    elif str(size) == '1080':
        names_size = ['Мультиформат, горизонтальная картинка', 'мультиформат, горизонтальная картинка, без текста']
    elif str(size) == '1080_256':
        names_size= ['Мультиформат широкая картинка + иконка 90х90']
    else:
        print('wrong size')
    
    multiformat_table_size = table[table['format'].isin(names_size)].reset_index(drop = True)
    multiformat_table_size = multiformat_table_size.groupby('banner_id').sum().reset_index()[['banner_id', 'shows', 'clicks']]
    multiformat_table_size['banner_id'] = multiformat_table_size['banner_id'].astype('int')
    
    return multiformat_table_size