import joblib
import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
import pathlib
import os
import io
import uuid
from functools import lru_cache
from fastapi import(
    FastAPI,
    Header,
    HTTPException,
    Depends,
    Request,
    File,
    UploadFile
    )
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseSettings
from PIL import Image
import uvicorn
import shutil
from pydantic import BaseModel

from fastapi import FastAPI
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

import sys
import os
cwd = os.getcwd()
sys.path.insert(1, cwd)
sys.path.insert(1, cwd + '/utils')
from predict_functions import test

help_dict = dict()
help_dict['img_data'] = None
help_dict['table_data'] = None
app = FastAPI()

class Item(BaseModel):
    iam_token: str = "t1.9euelZqPy5WKm5TIkZeeyZmZnJzHke3rnpWal8ybj4mKk8mPz5GYisjHx5nl8_d9Z31x-e8XKD4o_d3z9z0We3H57xcoPij9.gcV-TBO8bD-UDG1cwgY9mh9nJwbfeb7VEA5MpAHvVHc_R0diCv1p661u9hLbm6Pn9bEJ1i9bYD4EqVq56meMAw"
    folderId: str = "b1ggu2799duuhb9am08f"
    access_key_id: str = "AKIAYAN7LANB7J7QOP4Q"
    secret_access_key: str = "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"

BASE_DIR = pathlib.Path(__file__).parent
UPLOAD_DIR_IMG = BASE_DIR / "data" / "for_predict_data" / "imgs"
UPLOAD_DIR_TABLES = BASE_DIR / "data" / "for_predict_data" / "tables"

app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_headers=['X-Requested-With', 'Content-Type'])
app.mount('/static', StaticFiles(directory=BASE_DIR / 'static'))

@app.route('/')
async def homepage(request):
    html_file = BASE_DIR / 'view' / 'index_v0.html'
    return HTMLResponse(html_file.open().read())


@app.post("/img-echo/", response_class=FileResponse) # http POST
async def img_echo_view(file:UploadFile = File(...)):
    UPLOAD_DIR_IMG.mkdir(exist_ok=True)
    bytes_str = io.BytesIO(await file.read())
    try:
        img = Image.open(bytes_str)
        
    except:
        raise HTTPException(detail="Invalid image", status_code=400)
    fname = pathlib.Path(file.filename)
    fext = fname.suffix # .jpg, .txt
    dest = UPLOAD_DIR_IMG / f"{uuid.uuid1()}{fext}"
    img.save(dest)
    help_dict['img_data'] = dest
    return dest

@app.post("/tables-echo/", response_class=FileResponse) # http POST
async def tables_echo_view(file:UploadFile = File(...)):
    UPLOAD_DIR_TABLES.mkdir(exist_ok=True)
    try:
        fname = pathlib.Path(file.filename)
        fext = fname.suffix # .jpg, .txt
        dest = UPLOAD_DIR_TABLES / fname
        with open(dest,'wb') as f:
            shutil.copyfileobj(file.file, f)
    except:
        raise HTTPException(detail="Invalid image", status_code=400)
    help_dict['table_data'] = dest
    return dest

@app.post('/predict')
def predict(item: Item):
    """
    :param iris: input data from the post request
    :return: predicted iris type
    """
#     lolo(iris) 
    IMG_NAME = str(help_dict['img_data']).split('/')[-1].split('/')[-1]
    TABLE_NAME = str(help_dict['table_data']).split('/')[-1].split('/')[-1]
    print(IMG_NAME)
    print(TABLE_NAME)
    IAM_TOKEN = item.iam_token
    folderId = item.folderId
    access_key_id = item.access_key_id
    secret_access_key = item.secret_access_key
    predict = test(IMG_NAME, TABLE_NAME, IAM_TOKEN, folderId, access_key_id, secret_access_key)[0]
#     predict = 0
    return {
        "prediction": predict
    }


if __name__ == '__main__':
    # Run server using given host and port
    uvicorn.run(app, host='127.0.0.1', port=86)
