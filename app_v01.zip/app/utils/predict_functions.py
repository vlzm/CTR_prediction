import sys
import os
cwd = os.getcwd()
# sys.path.insert(1, cwd + '//utils')

import pandas as pd
import glob
import pickle


from recognition_functions import *
from postprocessing_functions import *

from catboost import CatBoostRegressor, cv, Pool
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from argparse import ArgumentParser

def test(use_img_name, use_table_name, use_IAM_TOKEN,  use_folderId, use_access_key_id, use_secret_access_key):
#     parser = ArgumentParser()
#     parser.add_argument('--img_name', type=str, default='a')
#     parser.add_argument('--table_name', type=str, default='b')
#     parser.add_argument('--IAM_TOKEN', type=str, default='c')
#     parser.add_argument('--folderId', type=str, default='d')
#     parser.add_argument('--access_key_id', type=str, default='g')
#     parser.add_argument('--secret_access_key', type=str, default='h')
#     args = parser.parse_args()
    
    IAM_TOKEN = use_IAM_TOKEN
    folderId = use_folderId

    access_key_id = use_access_key_id
    secret_access_key = use_secret_access_key

    img_name = use_img_name
    dict_all = {}
    objects = object_detection(cwd + '//data//for_predict_data//imgs//' + img_name,0.7,dict_all, access_key_id, secret_access_key)
    obj_list = list(objects[0]['Objects'].values)

    words_pic = text_recognition(cwd + '//data//for_predict_data//imgs//' + img_name, IAM_TOKEN, folderId)
    words_list = list(words_pic['Words'].values)

    data = pd.read_csv(cwd + '//data//for_predict_data//header//head_data.csv')
    data = data.drop(columns = ['Unnamed: 0'])

    target_column = ['CTR_1080']
    obj_columns = [x for x in data.columns if 'obj_' in x]
    word_columns = [x for x in data.columns if 'w_' in x]
    other_columns = ['topic_alias','title', 'cta_sites_full', 'primary', 'text_90', 'title_25', 'url']

    to_count_columns = ['topic_alias','title', 'cta_sites_full', 'url']
    to_one_hot_columns = ['topic_alias', 'cta_sites_full']
    to_target_mean_columns = ['topic_alias','title', 'cta_sites_full', 'url']

    data = data[obj_columns + word_columns + list(set(to_count_columns + to_one_hot_columns + to_target_mean_columns + target_column))].copy()

    raw_data_name = use_table_name
    raw_data = pd.read_excel(cwd + '//data//for_predict_data//tables//' + raw_data_name)
    raw_data = raw_data[['topic_alias','title', 'cta_sites_full', 'url']].copy()
    raw_data['url'] = raw_data['url'].astype('object').apply(lambda x: 'Empty' if isinstance(x, int) else x.split('/')[2])

    for col in data.columns:
        if col not in raw_data.columns:
            raw_data[col] = 0

    for col in data.columns:
        if col in obj_list:
            raw_data[col] = 1
        if col in words_list:
            raw_data[col] = 1

    raw_data[target_column[0]] = 0.0005

    target_column = ['CTR_1080']
    obj_columns = [x for x in data.columns if 'obj_' in x]
    word_columns = [x for x in data.columns if 'w_' in x]
    other_columns = ['topic_alias','title', 'cta_sites_full', 'primary', 'text_90', 'title_25', 'url']

    to_count_columns = ['topic_alias','title', 'cta_sites_full', 'url']
    to_one_hot_columns = ['topic_alias', 'cta_sites_full']
    to_target_mean_columns = ['topic_alias','title', 'cta_sites_full', 'url']

        data = data[obj_columns + word_columns + list(set(to_count_columns + to_one_hot_columns + to_target_mean_columns + target_column))].copy()
    data['flag'] = 0
    raw_data['flag'] = 1

    data = pd.concat([data, raw_data])
    count_columns = count_encoding(data, to_count_columns)
    one_hot_columns = one_hot_encoding(data, to_one_hot_columns)
    target_mean_columns = target_encoding(data, to_target_mean_columns, target_column[0])

    data = data[obj_columns + word_columns + count_columns + one_hot_columns + target_mean_columns + ['flag']].copy()

    final_data = data[data['flag'] > 0].reset_index(drop = True).drop(columns = ['flag'])

    numeric_features = target_mean_columns + count_columns + target_column
    cat_features = [x for x in final_data.columns if x not in numeric_features]

    final_data = type_encoding(final_data, cat_features)

    with open(cwd + '//data//for_predict_data//model_1080//first_model_1080_v1.pickle', 'rb') as f:
        model = pickle.load(f)

    predict = model.predict(final_data)
    print(predict)
    print('a')
    return(predict)



